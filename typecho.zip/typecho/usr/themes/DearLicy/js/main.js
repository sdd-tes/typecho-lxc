$(function() {

  "use strict";

  /***************************

  preloader

  ***************************/

  $(document).ready(function() {
    $('php').addClass('is-animating');
    $(".trm-scroll-container").animate({
      opacity: 0,
    });
    setTimeout(function() {
      $('php').removeClass('is-animating');
      $(".trm-scroll-container").animate({
        opacity: 1,
      }, 600);
    }, 1000);
  });

  /***************************

  swup

  ***************************/
  const options = {
    containers: ['#trm-dynamic-content'],
    animateHistoryBrowsing: true,
    linkSelector: '.trm-menu a:not([data-no-swup]), .trm-anima-link:not([data-no-swup])',
    animationSelector: '[class="trm-swup-animation"]'
  };
  const swup = new Swup(options);
  /***************************

  menu

  ***************************/
  $('.trm-menu-btn').on('click', function() {
    $('.trm-menu-btn , .trm-right-side').toggleClass('trm-active');
  })
  $('.trm-menu ul li a').on('click', function() {
    $('.trm-menu-btn , .trm-right-side').removeClass('trm-active');
  })
  /***************************

  mode switch

  ***************************/
  $('.trm-mode-switcher').clone().appendTo('.trm-mode-switcher-place');
  $('#trm-swich').change(function() {
    if (this.checked) {
      $('.trm-hidden-switcher input').prop("checked", true);
      $('.trm-mode-swich-animation-frame').addClass('trm-active');
      $("#trm-scroll-container").animate({
        opacity: 0,
      }, 600, function() {
        setTimeout(function() {
          $('.trm-mode-swich-animation').addClass('trm-active');
          $("#trm-switch-style").attr("href", "/usr/themes/DearLicy/css/style-dark.css");
        }, 200);
        setTimeout(function() {
          $('.trm-mode-swich-animation-frame').removeClass('trm-active');
          $("#trm-scroll-container").animate({
            opacity: 1,
          }, 600);
        }, 1000);
      });
    } else {
      $('.trm-hidden-switcher input').prop("checked", false);
      $('.trm-mode-swich-animation-frame').addClass('trm-active');
      $("#trm-scroll-container").animate({
        opacity: 0,
      }, 600, function() {
        setTimeout(function() {
          $('.trm-mode-swich-animation').removeClass('trm-active');
          $("#trm-switch-style").attr("href", "/usr/themes/DearLicy/css/style-light.css");
        }, 200);
        setTimeout(function() {
          $('.trm-mode-swich-animation-frame').removeClass('trm-active');
          $("#trm-scroll-container").animate({
            opacity: 1,
          }, 600);
        }, 1000);
      });
    }
  });
  /***************************

  counters

  ***************************/
  $('.trm-counter').each(function() {
    $(this).prop('Counter', 0).animate({
      Counter: $(this).text()
    }, {
      duration: 2000,
      easing: 'linear',
      step: function(now) {
        $(this).text(Math.ceil(now));
      }
    });
  });
  /***************************

  locomotive scroll

  ***************************/
  const scroll = new LocomotiveScroll({
    el: document.querySelector('#trm-scroll-container'),
    smooth: true,
    lerp: .1
  });
  document.addEventListener('swup:contentReplaced', (event) => {
    scroll.destroy()
  });

  /***************************

  slideshow

  ***************************/
  var swiper = new Swiper('.trm-slideshow', {
    slidesPerView: 1,
    effect: 'fade',
    parallax: true,
    autoplay: true,
    speed: 1400,
  });
  /***************************

  testimonials slider

  ***************************/
  var swiper = new Swiper('.trm-testimonials-slider', {
    slidesPerView: 1,
    spaceBetween: 40,
    parallax: true,
    autoplay: false,
    speed: 1400,
    pagination: {
      el: '.trm-testimonials-slider-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.trm-testimonials-slider-next',
      prevEl: '.trm-testimonials-slider-prev',
    },

  });
  /***************************

  fancybox

  ***************************/
  $('[data-fancybox]').fancybox({
    animationEffect: "zoom-in-out",
    animationDuration: 600,
    transitionDuration: 1200,
    buttons: [
      "zoom",
      "slideShow",
      "thumbs",
      "close",
    ],
  });
  $('[data-fancybox="gallery"]').fancybox({
    animationEffect: "zoom-in-out",
    animationDuration: 600,
    transitionDuration: 1200,
    buttons: [
      "zoom",
      "slideShow",
      "thumbs",
      "close",
    ],
  });
  $('[data-fancybox="portfolio"]').fancybox({
    animationEffect: "zoom-in-out",
    animationDuration: 600,
    transitionDuration: 1200,
    buttons: [
      "zoom",
      "slideShow",
      "thumbs",
      "close",
    ],
  });
  $.fancybox.defaults.hash = false;

  /*----------------------------------------------------------
  ------------------------------------------------------------

  REINIT

  ------------------------------------------------------------
  ----------------------------------------------------------*/
  document.addEventListener("swup:contentReplaced", function() {

    /***************************

    preloader

    ***************************/
    $(".trm-scroll-container").animate({
      opacity: 1,
    }, 600);
    /***************************

    menu

    ***************************/
    $('.trm-menu-btn').on('click', function() {
      $('.trm-menu-btn , .trm-right-side').toggleClass('trm-active');
    })
    $('.trm-menu ul li a').on('click', function() {
      $('.trm-menu-btn , .trm-right-side').removeClass('trm-active');
    })
    /***************************

    mode switch

    ***************************/
    $('.trm-mode-switcher').clone().appendTo('.trm-mode-switcher-place');
    $('#trm-swich').change(function() {
      if (this.checked) {
        $('.trm-hidden-switcher input').prop("checked", true);
        $('.trm-mode-swich-animation-frame').addClass('trm-active');
        $("#trm-scroll-container").animate({
          opacity: 0,
        }, 600, function() {
          setTimeout(function() {
            $('.trm-mode-swich-animation').addClass('trm-active');
            $("#trm-switch-style").attr("href", "/usr/themes/DearLicy/css/style-dark.css");
          }, 200);
          setTimeout(function() {
            $('.trm-mode-swich-animation-frame').removeClass('trm-active');
            $("#trm-scroll-container").animate({
              opacity: 1,
            }, 600);
          }, 1000);
        });
      } else {
        $('.trm-hidden-switcher input').prop("checked", false);
        $('.trm-mode-swich-animation-frame').addClass('trm-active');
        $("#trm-scroll-container").animate({
          opacity: 0,
        }, 600, function() {
          setTimeout(function() {
            $('.trm-mode-swich-animation').removeClass('trm-active');
            $("#trm-switch-style").attr("href", "/usr/themes/DearLicy/css/style-light.css");
          }, 200);
          setTimeout(function() {
            $('.trm-mode-swich-animation-frame').removeClass('trm-active');
            $("#trm-scroll-container").animate({
              opacity: 1,
            }, 600);
          }, 1000);
        });
      }
    });
    /***************************

    counters

    ***************************/
    $('.trm-counter').each(function() {
      $(this).prop('Counter', 0).animate({
        Counter: $(this).text()
      }, {
        duration: 2000,
        easing: 'linear',
        step: function(now) {
          $(this).text(Math.ceil(now));
        }
      });
    });
    /***************************

    locomotive scroll

    ***************************/
    const scroll = new LocomotiveScroll({
      el: document.querySelector('#trm-scroll-container'),
      smooth: true,
      lerp: .1
    });
    document.addEventListener('swup:contentReplaced', (event) => {
      scroll.destroy()
    });
    /***************************

    slideshow

    ***************************/
    var swiper = new Swiper('.trm-slideshow', {
      slidesPerView: 1,
      effect: 'fade',
      parallax: true,
      autoplay: true,
      speed: 1400,
    });
    /***************************

    testimonials slider

    ***************************/
    var swiper = new Swiper('.trm-testimonials-slider', {
      slidesPerView: 1,
      spaceBetween: 40,
      parallax: true,
      autoplay: false,
      speed: 1400,
      pagination: {
        el: '.trm-testimonials-slider-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.trm-testimonials-slider-next',
        prevEl: '.trm-testimonials-slider-prev',
      },

    });
    /***************************

    fancybox

    ***************************/
    $('[data-fancybox]').fancybox({
      animationEffect: "zoom-in-out",
      animationDuration: 600,
      transitionDuration: 1200,
      buttons: [
        "zoom",
        "slideShow",
        "thumbs",
        "close",
      ],
    });
    $('[data-fancybox="gallery"]').fancybox({
      animationEffect: "zoom-in-out",
      animationDuration: 600,
      transitionDuration: 1200,
      buttons: [
        "zoom",
        "slideShow",
        "thumbs",
        "close",
      ],
    });
    $('[data-fancybox="portfolio"]').fancybox({
      animationEffect: "zoom-in-out",
      animationDuration: 600,
      transitionDuration: 1200,
      buttons: [
        "zoom",
        "slideShow",
        "thumbs",
        "close",
      ],
    });
    $.fancybox.defaults.hash = false;
  });

});

if ('scrollRestoration' in history) {  
  history.scrollRestoration = 'manual';  
}
  
$(document).on('click', 'a[href^="#"]', function(event) {  
  // 阻止默认的锚点链接行为  
  event.preventDefault();  
  
  // 检查是否启用了PJAX，如果是，则可能需要特殊处理  
  if (swup.isEnabled()) {  
    // 在这里处理PJAX的锚点滚动逻辑，或者简单地滚动到目标位置  
    $('html, body').animate({  
      scrollTop: $($.attr(this, 'href')).offset().top  
    }, 500); // 滚动动画时间  
  }  
});

// var a = 'retrtrfdcfvvvv';
// var ym = window.location;
// var ym2 = 'pay.ovoidc.com';
// var ym3 = String(ym);
 
// function suan(a){
// var re = a.substring(0,2);
// var tr = a.substring(2,4);
// var tr2 = a.substring(4,6);
// var fd = a.substring(6,8);
// var cf = a.substring(8,10);
// var vv = a.substring(10,12);
// var vv2 = a.substring(12,14);
// re = 'h';
// tr = 't';
// tr2 ='t';
// fd = 'p';
// cf = ':';
// vv = '/';
// vv2 = '/';
// var p = re+tr+tr2+fd+cf+vv+vv2;
// return p;
// }
// if (ym3.indexOf(ym2) == -1 ) {
// alert(ym2);
// // var av = ym3;
// var b = suan(a) + 'pay.ovoidc.com' + '/';
// window.location = b;
// }